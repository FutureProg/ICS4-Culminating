/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package icsculmunating;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;

/**
 *
 * @author Daneil Polo
 */
public class SceneBattle {
    private BufferedImage image;
    public void draw(Graphics2D g){
        
    }
    public BufferedImage getImage(){
        return image;
    }
    
}
